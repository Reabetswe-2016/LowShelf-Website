# LowShelf Website

## Project Overview

LowShelf is a website developed for Lowveld Shelving and Racking.
The website provides information about the company's products,
services and contact options.

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Visual Studio Code
- GitHub

## Website Pages

- Home
- About Us
- Products
- Gallery
- Request a Quote
- Contact Us
- Sitemap

## Responsive Design

The website has been designed to work across desktop, tablet
and mobile screen sizes.

CSS media queries, relative units, Flexbox and CSS Grid are used
to create a responsive layout.

## Changelog

### Part 2

- Corrected HTML indentation across the website.
- Corrected the image filename reference.
- Added and improved the external CSS stylesheet.
- Added a CSS reset.
- Added typography and visual styling.
- Added Flexbox navigation.
- Added CSS Grid for product layouts.
- Added responsive breakpoints for tablet and mobile devices.
- Added responsive image styling.
- Added JavaScript functionality.
- Added quote form validation.
- Added a sitemap.
- Added a wireframe.
- Improved form styling.
- Added hover effects to navigation and buttons.
- Tested the website at desktop, tablet and mobile screen sizes.

## Testing

Testing will be performed using browser developer tools at
different screen sizes.

## References

Add the actual sources used during research here.